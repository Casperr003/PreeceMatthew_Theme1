using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 10f;            
    public float lifetime = 2f;          
    public float maxDistance = 15f;      

    private Vector2 direction;           
    private Vector3 playerPosition;      


    public void SetDirection(Vector2 dir, Vector3 playerPos)
    {
        direction = dir.normalized;
        playerPosition = playerPos;
    }

    private void Start()
    {

        Destroy(gameObject, lifetime);
    }

    private void Update()
    {
        transform.Translate(direction * speed * Time.deltaTime);


        if (Vector3.Distance(transform.position, playerPosition) > maxDistance)
        {
            Destroy(gameObject); 
        }
    }
}
