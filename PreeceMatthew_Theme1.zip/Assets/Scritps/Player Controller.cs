using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Movement
    public float moveSpeed = 5f;
    public Transform groundCheck;
    public LayerMask groundLayer;

    // Shooting
    public GameObject projectilePrefab;
    public Transform shootPoint;

    // Audio
    public AudioClip gunshotSound;
    private AudioSource audioSource;

    // Private
    private Rigidbody2D rb;
    private bool isGrounded;
    private bool facingRight = true;

    public bool disableGravity = true;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();

        if (disableGravity)
        {
            rb.gravityScale = 0; 
        }
    }

    void Update()
    {
        CheckGrounded();
        Move();
        Shoot();
    }

    private void CheckGrounded()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.1f, groundLayer);
    }

    private void Move()
    {
        float moveInputX = Input.GetAxis("Horizontal");

        float moveInputY = 0;
        if (isGrounded && Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            moveInputY = 1; 
        }
        else if (isGrounded && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)))
        {
            moveInputY = -1;  
        }

        rb.linearVelocity = new Vector2(moveInputX * moveSpeed, moveInputY * moveSpeed);

        if (moveInputX > 0 && !facingRight)
        {
            Flip();
        }
        else if (moveInputX < 0 && facingRight)
        {
            Flip();
        }
    }

    private void Shoot()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (gunshotSound != null && audioSource != null)
            {
                audioSource.PlayOneShot(gunshotSound);
            }

            Vector2 shootDirection = facingRight ? Vector2.right : Vector2.left;

            GameObject projectile = Instantiate(projectilePrefab, shootPoint.position, Quaternion.identity);
            Projectile projectileScript = projectile.GetComponent<Projectile>();

            projectileScript.SetDirection(shootDirection, transform.position);
        }
    }

    private void Flip()
    {
        facingRight = !facingRight;
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(groundCheck.position, 0.1f);
    }
}
