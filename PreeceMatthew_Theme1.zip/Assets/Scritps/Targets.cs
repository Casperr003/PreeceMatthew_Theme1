using UnityEngine;

public class Target : MonoBehaviour
{
    public AudioClip targetBreakSound;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Projectile"))
        {
            if (targetBreakSound != null)
            {
                AudioSource.PlayClipAtPoint(targetBreakSound, transform.position);
            }

            GameManager.instance.AddScore(1);

            Destroy(collision.gameObject);

            Destroy(gameObject); 
        }
    }
}
